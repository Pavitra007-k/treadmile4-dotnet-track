﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RqwSqlQueriesDemo.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RqwSqlQueriesDemo.Controllers
{
    public class ProductsController : Controller
    {
        private TestDbContext testDbContext;
        public ProductsController(TestDbContext testDbContext)
        {
            this.testDbContext = testDbContext;
        }
        // GET: /<controller>/
        public IActionResult RawSqlInline()
        {
            var products = testDbContext.Products
            .FromSqlRaw("SELECT * FROM dbo.Products")//
            .ToList();
            return View("Index",products);
        }
        public IActionResult RawSqlStoredProcedure()
        {
            var products = testDbContext.Products
            .FromSqlRaw("Exec dbo.uspGetProducts")
            .ToList();
            return View("Index", products);
        }
        public IActionResult RawSqlStoredProcedureWithParmas(int? id)
        {
            //var productId = 1;
            var products = testDbContext.Products
            .FromSqlInterpolated($"Exec dbo.uspGetProductById {id}")
            .ToList();
            return View("Index", products);
        }
    }
}
