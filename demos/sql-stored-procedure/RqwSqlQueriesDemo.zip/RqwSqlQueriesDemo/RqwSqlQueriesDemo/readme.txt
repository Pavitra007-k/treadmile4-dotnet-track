﻿stored procedure
procedure or function is set of statements
stored:
anonymous block: set of statments

Raw SQL:
1)When LINQ queries doesn't support the desired requiremeent
2)When LINQ queries performance is not according to the expectations
