﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductCrud.Controllers
{
    [Route("customers")]
    public class CustomersController : Controller
    {
        [Route("landing")]//route: /customers/landing
        public IActionResult Index()
        {
            return View();
        }

        [Route("edit/{id}")]//route: /customers/edit/1
        public IActionResult Edit(int id)
        {
            return View();
        }

        [Route("~/about")]//route: /about
        public IActionResult About(int id)
        {
            
            return View();
        }
    }
}
