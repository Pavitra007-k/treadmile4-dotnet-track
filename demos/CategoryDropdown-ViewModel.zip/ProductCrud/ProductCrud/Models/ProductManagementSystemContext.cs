﻿using System;
using Microsoft.EntityFrameworkCore;

namespace ProductCrud.Models
{
    public class ProductManagementSystemDbContext:DbContext
    {
        public ProductManagementSystemDbContext(DbContextOptions<ProductManagementSystemDbContext> options):base(options)
        {

        }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductCategory> ProductCategories { get; set; }

    }
}
