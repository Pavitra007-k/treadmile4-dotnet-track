﻿using System;
using System.Collections.Generic;

namespace ProductCrud.Models
{
    public class ProductCategoryViewModel
    {
        public List<ProductCategory> ProductCategories { get; set; }
        public Product Product { get; set; }
    }
}
