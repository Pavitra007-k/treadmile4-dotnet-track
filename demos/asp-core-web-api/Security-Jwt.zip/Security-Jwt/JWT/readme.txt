﻿1) From postman 
http://localhost:59674/api/authenticate
Post request

Authentication: Basic
username: your-username
password: your-password

Will receive jwt token copy that

2) http://localhost:59674/api/values
Get Request

In Authorization Header

Authentication: 
Bearer Token:( paste the jwt token with out quotes)

