﻿Reference

https://docs.microsoft.com/en-us/aspnet/core/security/cors?view=aspnetcore-2.2