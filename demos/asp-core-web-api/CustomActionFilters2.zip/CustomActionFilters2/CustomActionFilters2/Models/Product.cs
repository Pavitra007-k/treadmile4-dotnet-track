﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CustomActionFilters2.Models
{
    public class Product
    {

        public int Id { get; set; }
        [Required]
        [StringLength(5,MinimumLength =2)]
        public string Name { get; set; }
        public int  Price { get; set; }
    }
}
