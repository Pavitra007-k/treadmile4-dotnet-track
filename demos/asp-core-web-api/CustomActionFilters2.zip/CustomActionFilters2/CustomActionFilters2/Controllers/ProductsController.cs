﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomActionFilters2.Filters;
using CustomActionFilters2.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CustomActionFilters2.Controllers
{
    [ServiceFilter(typeof(MyCustomActionFilter))]
    [ApiController]
    [Route("[controller]")]
    public class ProductsController : Controller
    {
        // GET: /<controller>/
        public string Index()
        {
            //int a = 10;
            //int b = 0;
            //int res = a / b;
            return "no products available now!";
        }
        
        [HttpPost]
        public IActionResult Create(Product product)
        {
            return Ok();
        }
    }
}
