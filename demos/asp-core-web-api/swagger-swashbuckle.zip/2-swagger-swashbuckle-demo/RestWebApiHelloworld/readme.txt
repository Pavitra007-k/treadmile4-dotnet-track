﻿1) From the Manage NuGet Packages install "Swashbuckle.AspNetCore"
Install-Package Swashbuckle.AspNetCore -Version 5.0.0-rc4
2) In the Startup class, import the following namespace to 
use the OpenApiInfo class:
using Microsoft.OpenApi.Models;
3)Add the Swagger generator to the services collection in the 
Startup.ConfigureServices method:
public void ConfigureServices(IServiceCollection services)
{
    // Register the Swagger generator, defining 1 or more Swagger documents
    services.AddSwaggerGen(c =>
    {
        c.SwaggerDoc("v1", new OpenApiInfo { Title = "My API", Version = "v1" });
    });
}
4)In the Startup.Configure method, enable the middleware for 
serving the generated JSON document and the Swagger UI:


