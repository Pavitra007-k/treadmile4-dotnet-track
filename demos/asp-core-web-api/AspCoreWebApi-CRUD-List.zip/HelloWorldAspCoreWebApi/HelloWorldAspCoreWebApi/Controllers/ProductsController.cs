﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HelloWorldAspCoreWebApi.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HelloWorldAspCoreWebApi.Controllers
{
    [Route("api/[controller]")]
    public class ProductsController : Controller
    {
        private static List<Product> products = new List<Product>
        {
            new Product{Id=1,Name="Pen",Price=25},
            new Product{Id=2,Name="Pencil",Price=5},
            new Product{Id=3,Name="Eraser",Price=3},
            new Product{Id=4,Name="Sharpner",Price=4},
        };
        // GET: api/values
        [HttpGet]
        public IEnumerable<Product> Get()
        {
            return products;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public Product Get(int id)
        {
            return products.Where(p => p.Id == id).FirstOrDefault();
        }

        // POST api/values
        [HttpPost]
        public string Post([FromBody] Product product)
        {
            products.Add(product);
            return "Product created successfully!";
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public string Put(int id, [FromBody] Product product)
        {
            var p = products.Where(pro => pro.Id == id).FirstOrDefault();
            p.Name = product.Name;
            p.Price = product.Price;
            return "Product updated successfully!";
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public string Delete(int id)
        {
            var product = products.Where(p => p.Id == id).FirstOrDefault();
            products.Remove(product);
            return "Product deleted successfully!";
        }
    }
}
