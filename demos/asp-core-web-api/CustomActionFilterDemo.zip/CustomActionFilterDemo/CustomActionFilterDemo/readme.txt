﻿1) Create a new folder "Filters" in root folder

2) Add a class and write the following code

public class MyActionFilterAttribute : IActionFilter
    {
        public void OnActionExecuting(ActionExecutingContext context)
        {
            // Do something before the action executes.
            Debug.Write("*****************************************************");
            Debug.Write("Action Executing Context");
            Debug.Write(MethodBase.GetCurrentMethod(), context.HttpContext.Request.Path);
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            // Do something after the action executes.
            Debug.Write("*****************************************************");
            Debug.Write("Action Executed Context");
            Debug.Write(MethodBase.GetCurrentMethod(), context.HttpContext.Request.Path);
        }
    }

3)Register ActionFilterAttribute in Startup.cs file
services.AddScoped<MyActionFilterAttribute>();

4) Apply MyActionFilterAttribute on ValuesController in ValuesController.cs file
[ServiceFilter(typeof(MyActionFilterAttribute))]
public class ValuesController : ControllerBase
        
5) Start Debug ane see in output window


reference
https://docs.microsoft.com/en-us/aspnet/core/mvc/controllers/filters?view=aspnetcore-2.2#action-filters-1