﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProductCrud.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductCrud.Controllers
{
    public class ProductsController : Controller
    {
        private List<Product> products = new List<Product>
        {
            new Product{Id=1,Name="Pen",Price=25},
            new Product{Id=2,Name="Pencil",Price=5},
            new Product{Id=3,Name="Eraser",Price=5}
        };
        public IActionResult Index()
        {

            return View(products);
        }
       [HttpGet]
        public IActionResult Create()

        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Product product)
        {
            products.Add(product);
            return View("Index",products);
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var product = products.Where(p => p.Id == id).FirstOrDefault();
            return View(product);
        }
        [HttpPost]
        public IActionResult Edit(Product product)
        {
            var p = products.Where(pro => pro.Id == product.Id).FirstOrDefault();
            p.Name = product.Name;
            p.Price = product.Price;
            return View("Index", products);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var product = products.Where(p => p.Id == id).FirstOrDefault();
            return View(product);
        }
        [HttpPost]
        public IActionResult Delete(Product product)
        {
            var p = products.Where(pro => pro.Id == product.Id).FirstOrDefault();
            products.Remove(p);
           
            return View("Index", products);
        }
    }
}
