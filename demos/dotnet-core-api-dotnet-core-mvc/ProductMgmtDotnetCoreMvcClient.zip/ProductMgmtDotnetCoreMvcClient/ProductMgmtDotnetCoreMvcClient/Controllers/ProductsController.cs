﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using ProductMgmtDotnetCoreMvcClient.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductMgmtDotnetCoreMvcClient.Controllers
{
    public class ProductsController : Controller
    {

        private static HttpClient httpClient = new HttpClient();

        
        // GET: /<controller>/
        public async Task<IActionResult> Index()
        {
            var response = await httpClient.GetAsync("https://localhost:5001/api/products");
            response.EnsureSuccessStatusCode();
            var content = await response.Content.ReadAsStringAsync();
            var products = new List<Product>();
            if (response.Content.Headers.ContentType.MediaType == "application/json")
            {
                products = JsonConvert.DeserializeObject<List<Product>>(content);
            }
            //else if (response.Content.Headers.ContentType.MediaType == "application/xml")
            //{
            //    var serializer = new XmlSerializer(typeof(List<Product>));
            //    products = (List<Product>)serializer.Deserialize(new StringReader(content));
            //}
            return View(products);
        }

        [HttpGet]
        public  IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create([Bind("Name,Price")]Product product)
        {

            var serializedProductToCreate = JsonConvert.SerializeObject(product);

            var request = new HttpRequestMessage(HttpMethod.Post, "https://localhost:5001/api/products");
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            request.Content = new StringContent(serializedProductToCreate);
            request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            return RedirectToAction("Index");
        }
    }
}
