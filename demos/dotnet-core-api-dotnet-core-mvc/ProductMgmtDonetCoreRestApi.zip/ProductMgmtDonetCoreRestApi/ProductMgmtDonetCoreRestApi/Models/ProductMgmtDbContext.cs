﻿using System;
using Microsoft.EntityFrameworkCore;

namespace ProductMgmtDonetCoreRestApi.Models
{
    public class ProductMgmtDbContext:DbContext
    {
        public ProductMgmtDbContext(DbContextOptions<ProductMgmtDbContext> options):base(options)
        {
        }
        public DbSet<Product> Products { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasData(
                new Product {Id=1, Name = "Pen",Price=25 },
                new Product {Id=2, Name = "Pencil", Price = 5 }
                ) ;
        }
    }
}
