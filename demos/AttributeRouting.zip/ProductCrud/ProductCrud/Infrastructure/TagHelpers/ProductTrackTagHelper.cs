﻿using System;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace ProductCrud.Infrastructure.TagHelpers
{
    [HtmlTargetElement("ProductTrack")]
    public class ProductTrackTagHelper : TagHelper
    {
        public string TrackName { get; set; }//PascalCase-class,method,property,interface
                                             //camelCase-local variable, parameters, fieled

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            string preContent = $@"
                <h2>{TrackName}</h2>
                <div class='row'>
            ";
            const string postContent = @"
                </div>
            ";
            output.TagName = "div";
            output.Attributes.SetAttribute("class", "track");
            output.PreContent.SetHtmlContent(preContent);
            output.PostContent.SetHtmlContent(postContent);

        }
    }
}
