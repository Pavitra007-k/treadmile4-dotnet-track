﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductCrud.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductCrud.Controllers
{
    public class ProductsController : Controller
    {
        private ProductManagementSystemDbContext productManagementDb;//dependency injection
        public ProductsController(ProductManagementSystemDbContext productManagementDb)
        {
            this.productManagementDb = productManagementDb;
        }
        //private static List<Product> products = new List<Product>
        //{
        //    new Product{Id=1,Name="Pen",Price=25},
        //    new Product{Id=2,Name="Pencil",Price=5},
        //    new Product{Id=3,Name="Eraser",Price=5}
        //};
        public async Task<IActionResult> Index()
        {
            return View(await productManagementDb.Products.ToListAsync());
        }
       [HttpGet]
        public async Task<IActionResult> Create()
        {
            ProductCategoryViewModel productCategoryViewModel = new ProductCategoryViewModel();
            productCategoryViewModel.ProductCategories =await productManagementDb.ProductCategories.ToListAsync();
            productCategoryViewModel.Product = new Product();

            return View(productCategoryViewModel);
        }
        [HttpPost]
        public async Task<IActionResult> Create(Product product)
        {
            //products.Add(product);
            await productManagementDb.Products.AddAsync(product);
            await productManagementDb.SaveChangesAsync();
            return View("Index",await productManagementDb.Products.ToListAsync());
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            //var product = products.Where(p => p.Id == id).FirstOrDefault();
            var product = productManagementDb.Products.Where(p => p.Id == id).FirstOrDefault();
            return View(product);
        }
        [HttpPost]
        public IActionResult Edit(Product product)
        {
            //var p = products.Where(pro => pro.Id == product.Id).FirstOrDefault();
            //p.Name = product.Name;
            //p.Price = product.Price;
            productManagementDb.Products.Update(product);
            productManagementDb.SaveChanges();
            return View("Index");
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            //var product = products.Where(p => p.Id == id).FirstOrDefault();
            var product = productManagementDb.Products.Where(p => p.Id == id).FirstOrDefault();
            return View(product);
        }
        [HttpPost]
        public IActionResult Delete(Product product)
        {
            //var p = products.Where(pro => pro.Id == product.Id).FirstOrDefault();
            //products.Remove(p);
            productManagementDb.Products.Remove(product);
            productManagementDb.SaveChanges();
            return View("Index",productManagementDb.Products.ToList());
        }
    }
}
