﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProductCrud.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductCrud.Controllers
{
    public class AccountController : Controller
    {
        private ProductManagementSystemDbContext productManagementSystemDbContext;
        public AccountController(ProductManagementSystemDbContext productManagementSystemDbContext)
        {
            this.productManagementSystemDbContext = productManagementSystemDbContext;    
        }
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> SignUp(ApplicationUser applicationUser)
        {
            productManagementSystemDbContext.Users.Add(applicationUser);
            await productManagementSystemDbContext.SaveChangesAsync();
            ViewBag.Message = "Signup successful!";
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(ApplicationUser applicationUser)
        {
            var user = productManagementSystemDbContext
                .Users.Where(u => u.Email == applicationUser.Email && u.Password == applicationUser.Password)
                .FirstOrDefault();
            if(user!=null)
            ViewBag.Message = "Login successful!";
            else
                ViewBag.Message = "Invalid username/password!";
            return View();
        }
    }
}
