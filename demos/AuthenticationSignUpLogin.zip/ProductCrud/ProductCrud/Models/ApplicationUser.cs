﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ProductCrud.Models
{
    public class ApplicationUser
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Please provide a valid email")]
        [DataType(DataType.EmailAddress)]
        
        public string Email { get; set; }
        [Required(ErrorMessage ="Please provide password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
