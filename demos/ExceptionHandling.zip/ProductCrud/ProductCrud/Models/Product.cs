﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ProductCrud.Models
{
    public class Product
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="Please provide product name")]
        [StringLength(maximumLength:100)]
        public string Name { get; set; }
        [Required(ErrorMessage ="Please provide price")]
        public int Price { get; set; }
        [Required(ErrorMessage ="Please provide mfg date")]
        [DataType(DataType.Date)]
        public DateTime MfgDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime ExpDate { get; set; }
        [Required(ErrorMessage ="Please provide product discontinued status")]
        public bool IsDontinued { get; set; }
        public float Rating { get; set; }
        public int  CategoryId { get; set; }
        
    }
}
