﻿using System;
using Microsoft.AspNetCore.Mvc;
using ProductCrud.Models;

namespace ProductCrud.Infrastructure.ViewComponents
{
    public class ProductCardViewComponent:ViewComponent
    {
        public IViewComponentResult Invoke(
            Product product)
        {
            return View(product);
        }
    }
}
