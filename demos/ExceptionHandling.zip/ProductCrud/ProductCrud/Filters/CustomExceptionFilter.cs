﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;

namespace ProductCrud.Filters
{
    public class CustomExceptionFilter:ExceptionFilterAttribute,IExceptionFilter
    {
        private HttpContextAccessor httpContextAccessor;
        public CustomExceptionFilter(HttpContextAccessor httpContextAccessor)
        {
            this.httpContextAccessor = httpContextAccessor;
        }
        public override void OnException(ExceptionContext context)
        {
            httpContextAccessor.HttpContext.Response.WriteAsync("Internal server error, please contact admin");
            
        }
    }
    
}
