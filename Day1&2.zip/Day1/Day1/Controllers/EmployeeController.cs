﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Day1.Models;
using Microsoft.AspNetCore.Mvc;


namespace Day1.Controllers
{
    public class EmployeeController : Controller
    {
        private static List<Employees> Employeess = new List<Employees>
        {
        new Employees{Id=1,Name="Pradeep",Stream=".Net"},
         new Employees{Id=2,Name="Raj",Stream="Java"},
        };
        public IActionResult Index()
        {
            
            return View(Employeess);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employees emp)
        {
            Employeess.Add(emp);
            return View("Index",Employeess);
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var details = Employeess.Where(res => res.Id == id).FirstOrDefault();
            return View(details);
        }
        [HttpPost]
        public IActionResult Edit(Employees emp)
        {
            var details = Employeess.Where(res => res.Id == emp.Id).FirstOrDefault();
            details.Name = emp.Name;
            details.Stream = emp.Stream;
            return View("Index", Employeess);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {

            var details = Employeess.Where(res => res.Id == id).FirstOrDefault();
            return View(details);
        }
        [HttpPost]
        public IActionResult Delete(Employees emp)
        {
            var details = Employeess.Where(res => res.Id == emp.Id).FirstOrDefault();
            Employeess.Remove(details);
          //  details.Stream = emp.Stream;
            return View("Index", Employeess);
        }

    }
}
