﻿using Day1.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day1.Infrastructure.ViewComponents
{
    public class EmployeeCardViewComponent: ViewComponent
    {
        public IViewComponentResult Invoke(
           Employees employees)
        {
            return View(employees);
        }
    }
}
